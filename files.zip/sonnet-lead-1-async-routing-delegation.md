# Claude Code Prompt: Sonnet Lead #1 - Async Routing & Delegation Layer

## Your Role
You are **Implementation Lead** for the async routing and delegation infrastructure. You will transform DyTopo's semantic routing from a CPU-bound sequential operation into a high-performance parallel system, implement safe concurrent delegation with cycle detection, and build the agent communication layer that enables scalable multi-agent reasoning.

## Context: What You're Building
The Opus lead is establishing vLLM async infrastructure. You are building **on top** of that to create:
- Async-safe routing graph construction
- Parallel agent delegation with backpressure
- Message routing with topological safety
- Agent state management across concurrent execution
- Retry and failure recovery for delegated tasks

## Your Scope
1. **Async Routing Pipeline** - Concurrent embedding + graph construction
2. **Delegation System** - Safe task splitting and sub-agent spawning  
3. **Message Protocol** - Agent-to-agent communication with routing
4. **State Synchronization** - Concurrent-safe agent state
5. **Performance Safeguards** - Rate limiting, token budgets, circuit breakers

## Critical Architecture Patterns

### 1. Async Routing Graph Construction

**Current Sequential Flow:**
```
1. Collect descriptors (sequential) - 12-20s
2. Embed all descriptors (CPU, batch) - 2s
3. Compute similarity matrix - <0.1s
4. Build graph - <0.1s
5. Topological sort - <0.1s
Total: ~15-20s
```

**Target Async Flow:**
```
1. Collect descriptors (parallel) - 3-5s ← IMPROVEMENT
2. Embed all descriptors (CPU, batch) - 2s
3. Compute similarity matrix - <0.1s
4. Build graph - <0.1s  
5. Topological sort - <0.1s
Total: ~5-7s
```

**Implementation:**
```python
class AsyncRoutingEngine:
    """
    Manages concurrent-safe routing graph construction.
    
    Thread Safety:
    - Embedding model (MiniLM) is NOT thread-safe
    - Use asyncio.Lock to serialize embedding calls
    - Similarity computation (numpy) is reentrant
    - Graph construction (networkx) is reentrant
    """
    
    def __init__(self, embedder, tau: float = 0.3, K_in: int = 3):
        self.embedder = embedder
        self.tau = tau
        self.K_in = K_in
        self._embed_lock = asyncio.Lock()  # Protect non-thread-safe embedder
        
    async def build_routing_graph(
        self,
        descriptors: Dict[str, Descriptor]
    ) -> nx.DiGraph:
        """
        Build routing graph from descriptors.
        
        Steps:
        1. Extract all key/query strings
        2. Embed them (CRITICAL: must serialize via lock)
        3. Compute cosine similarity matrix
        4. Apply threshold and build directed graph
        5. Detect and break cycles
        6. Return topologically sorted graph
        """
        # Step 1: Extract all text to embed
        texts = []
        text_to_agent = {}  # Map text back to agent
        
        for agent_id, desc in descriptors.items():
            key_text = f"key: {desc.key}"
            query_text = f"query: {desc.query}"
            texts.extend([key_text, query_text])
            text_to_agent[key_text] = (agent_id, "key")
            text_to_agent[query_text] = (agent_id, "query")
        
        # Step 2: Embed (serialized via lock)
        embeddings = await self._embed_batch(texts)
        
        # Step 3: Compute similarity matrix (CPU-bound but fast)
        similarity = await asyncio.to_thread(
            self._compute_similarity_matrix,
            embeddings,
            descriptors.keys()
        )
        
        # Step 4: Build graph
        graph = self._construct_graph(similarity, descriptors.keys())
        
        # Step 5: Break cycles
        graph = self._break_cycles(graph)
        
        return graph
    
    async def _embed_batch(self, texts: List[str]) -> np.ndarray:
        """
        Embed text batch with lock protection.
        
        CRITICAL: sentence-transformers models are NOT thread-safe.
        Even though we're using asyncio (single-threaded), we serialize
        embedding calls to prevent any potential issues.
        """
        async with self._embed_lock:
            # Run CPU-bound embedding in thread pool
            embeddings = await asyncio.to_thread(
                self.embedder.encode,
                texts,
                normalize_embeddings=True,
                show_progress_bar=False
            )
            return embeddings
    
    def _compute_similarity_matrix(
        self,
        embeddings: np.ndarray,
        agent_ids: List[str]
    ) -> np.ndarray:
        """
        Compute cosine similarity between all key/query pairs.
        
        Returns: NxN matrix where M[i][j] = similarity(agent_i.query, agent_j.key)
        """
        n = len(agent_ids)
        S = np.zeros((n, n))
        
        # embeddings layout: [agent0_key, agent0_query, agent1_key, agent1_query, ...]
        for i in range(n):
            query_emb = embeddings[2*i + 1]  # query embedding
            for j in range(n):
                if i == j:
                    continue
                key_emb = embeddings[2*j]  # key embedding
                S[i][j] = np.dot(query_emb, key_emb)  # Already normalized
        
        return S
    
    def _construct_graph(
        self,
        similarity: np.ndarray,
        agent_ids: List[str]
    ) -> nx.DiGraph:
        """
        Construct directed graph from similarity matrix.
        
        Edge i→j exists if:
        - similarity(agent_i.query, agent_j.key) >= tau
        - j is in top-K_in targets for i
        """
        G = nx.DiGraph()
        agent_list = list(agent_ids)
        n = len(agent_list)
        
        for i in range(n):
            # Get top K_in most similar agents
            row = similarity[i, :]
            top_k_indices = np.argsort(row)[-self.K_in:][::-1]
            
            for j in top_k_indices:
                if i != j and row[j] >= self.tau:
                    G.add_edge(
                        agent_list[i],
                        agent_list[j],
                        weight=float(row[j])
                    )
        
        return G
    
    def _break_cycles(self, G: nx.DiGraph) -> nx.DiGraph:
        """
        Detect and break cycles to ensure DAG.
        
        Strategy: Remove lowest-weight edge in each cycle.
        """
        while not nx.is_directed_acyclic_graph(G):
            try:
                cycle = nx.find_cycle(G)
                # Find lowest weight edge in cycle
                min_edge = min(cycle, key=lambda e: G[e[0]][e[1]].get("weight", 0))
                G.remove_edge(min_edge[0], min_edge[1])
            except nx.NetworkXNoCycle:
                break
        
        return G
```

### 2. Concurrent Delegation System

**Task Delegation Pattern:**
```python
class DelegationManager:
    """
    Manages task delegation with concurrency control.
    
    Use Case: When an agent determines it needs help, it can spawn
    sub-agents to work on subtasks in parallel.
    
    Safety Guarantees:
    1. Max delegation depth (prevent infinite recursion)
    2. Token budget enforcement (prevent runaway costs)
    3. Timeout per delegation (prevent hung subtasks)
    4. Backpressure (limit concurrent delegations)
    """
    
    def __init__(
        self,
        orchestrator: AsyncDyTopoOrchestrator,
        max_depth: int = 2,
        max_concurrent_delegations: int = 4
    ):
        self.orchestrator = orchestrator
        self.max_depth = max_depth
        self.delegation_semaphore = asyncio.Semaphore(max_concurrent_delegations)
        self.delegation_tree: Dict[str, List[str]] = {}  # parent -> [children]
        
    async def delegate_task(
        self,
        parent_agent_id: str,
        subtask: str,
        context: Dict,
        depth: int = 0
    ) -> str:
        """
        Delegate subtask to new mini-swarm.
        
        Returns: Result from delegation
        Raises: DelegationError on failure
        """
        if depth >= self.max_depth:
            raise DelegationError(f"Max delegation depth {self.max_depth} reached")
        
        async with self.delegation_semaphore:
            # Create delegation ID
            delegation_id = f"{parent_agent_id}_sub_{uuid.uuid4().hex[:8]}"
            
            # Track delegation
            if parent_agent_id not in self.delegation_tree:
                self.delegation_tree[parent_agent_id] = []
            self.delegation_tree[parent_agent_id].append(delegation_id)
            
            try:
                # Create mini-swarm for subtask
                result = await asyncio.wait_for(
                    self._execute_delegation(
                        delegation_id,
                        subtask,
                        context,
                        depth
                    ),
                    timeout=300.0  # 5 min max per delegation
                )
                return result
                
            except asyncio.TimeoutError:
                raise DelegationError(f"Delegation {delegation_id} timed out")
            except Exception as e:
                raise DelegationError(f"Delegation {delegation_id} failed: {e}")
    
    async def _execute_delegation(
        self,
        delegation_id: str,
        subtask: str,
        context: Dict,
        depth: int
    ) -> str:
        """
        Execute delegation as mini-swarm.
        
        Mini-swarm has:
        - Reduced agent count (2-3 agents)
        - Reduced round limit (2 rounds)
        - Reduced token budget (2048 per agent)
        """
        # Create specialized mini-swarm
        mini_agents = self._create_delegation_agents(subtask, context)
        mini_manager = self._create_delegation_manager(subtask)
        
        mini_orchestrator = AsyncDyTopoOrchestrator(
            agents=mini_agents,
            manager=mini_manager,
            embedder=self.orchestrator.embedder,
            vllm_base_url=self.orchestrator.client.base_url,
            tau=0.3,
            K_in=2,
            T_max=2,  # Only 2 rounds for delegations
            max_concurrent=4,
            token_budget_per_agent=2048  # Reduced budget
        )
        
        result = await mini_orchestrator.run(subtask)
        return result.final_answer
    
    def _create_delegation_agents(
        self,
        subtask: str,
        context: Dict
    ) -> List[Agent]:
        """
        Create specialized agents for delegation.
        
        Typical delegation patterns:
        - Verification: Verifier + Critic
        - Decomposition: Planner + Executor
        - Research: Searcher + Synthesizer
        """
        # Analyze subtask to determine agent types needed
        if "verify" in subtask.lower() or "check" in subtask.lower():
            return [VerifierAgent(), CriticAgent()]
        elif "plan" in subtask.lower() or "decompose" in subtask.lower():
            return [PlannerAgent(), ExecutorAgent()]
        else:
            # Default: general purpose agents
            return [AnalystAgent(), SynthesizerAgent()]
```

### 3. Agent Communication Protocol

**Message Routing:**
```python
@dataclass
class AgentMessage:
    """Message passed between agents via routing graph."""
    from_agent: str
    to_agent: str
    content: str
    similarity: float
    round_number: int
    timestamp: float
    
class MessageRouter:
    """
    Routes messages between agents according to graph structure.
    
    Ensures:
    - Messages only flow along edges
    - Topological order respected
    - No message duplication
    - Bounded message history
    """
    
    def __init__(self, max_messages_per_agent: int = 10):
        self.max_messages = max_messages_per_agent
        self.message_history: Dict[str, List[AgentMessage]] = {}
        
    async def route_messages(
        self,
        graph: nx.DiGraph,
        outputs: Dict[str, str],
        round_number: int
    ) -> Dict[str, List[AgentMessage]]:
        """
        Route messages based on graph edges.
        
        Returns: Dict[agent_id -> incoming_messages]
        """
        routed_messages = {node: [] for node in graph.nodes()}
        
        for from_agent in outputs.keys():
            for to_agent in graph.successors(from_agent):
                weight = graph[from_agent][to_agent].get("weight", 0.0)
                
                msg = AgentMessage(
                    from_agent=from_agent,
                    to_agent=to_agent,
                    content=outputs[from_agent],
                    similarity=weight,
                    round_number=round_number,
                    timestamp=time.time()
                )
                
                routed_messages[to_agent].append(msg)
                
                # Track history
                if to_agent not in self.message_history:
                    self.message_history[to_agent] = []
                self.message_history[to_agent].append(msg)
                
                # Prune old messages
                if len(self.message_history[to_agent]) > self.max_messages:
                    self.message_history[to_agent] = \
                        self.message_history[to_agent][-self.max_messages:]
        
        # Sort messages by similarity (highest first)
        for agent_id in routed_messages:
            routed_messages[agent_id].sort(
                key=lambda m: m.similarity,
                reverse=True
            )
        
        return routed_messages
    
    def get_message_context(
        self,
        agent_id: str,
        include_history: bool = True
    ) -> str:
        """
        Build message context for agent prompt.
        
        Returns formatted string with incoming messages.
        """
        if agent_id not in self.message_history:
            return "No incoming messages."
        
        messages = self.message_history[agent_id]
        if not include_history:
            # Only current round
            current_round = max(m.round_number for m in messages)
            messages = [m for m in messages if m.round_number == current_round]
        
        lines = []
        for msg in messages:
            lines.append(f"--- From {msg.from_agent} (similarity: {msg.similarity:.3f}) ---")
            lines.append(msg.content)
            lines.append("")
        
        return "\n".join(lines)
```

### 4. Performance Safeguards

**Rate Limiting & Circuit Breaker:**
```python
class PerformanceSafeguards:
    """
    Enforces performance and safety constraints.
    
    Prevents:
    - Runaway token consumption
    - Infinite delegation loops
    - Resource exhaustion
    - Cascading failures
    """
    
    def __init__(
        self,
        token_budget_total: int = 100000,
        max_requests_per_minute: int = 120,
        circuit_breaker_threshold: int = 5
    ):
        self.token_budget = token_budget_total
        self.tokens_consumed = 0
        
        # Rate limiting
        self.request_times: List[float] = []
        self.max_rpm = max_requests_per_minute
        
        # Circuit breaker
        self.failure_count = 0
        self.circuit_breaker_threshold = circuit_breaker_threshold
        self.circuit_open = False
        self.circuit_reset_time = None
        
    async def check_rate_limit(self):
        """Enforce requests-per-minute limit."""
        now = time.time()
        
        # Remove requests older than 1 minute
        self.request_times = [
            t for t in self.request_times
            if now - t < 60.0
        ]
        
        if len(self.request_times) >= self.max_rpm:
            # Calculate wait time
            oldest = self.request_times[0]
            wait_time = 60.0 - (now - oldest)
            
            logger.warning(f"Rate limit reached, waiting {wait_time:.1f}s")
            await asyncio.sleep(wait_time)
            
        self.request_times.append(now)
    
    def check_token_budget(self, tokens_needed: int):
        """Enforce total token budget."""
        if self.tokens_consumed + tokens_needed > self.token_budget:
            raise TokenBudgetExceeded(
                f"Token budget {self.token_budget} exceeded. "
                f"Used: {self.tokens_consumed}, Needed: {tokens_needed}"
            )
    
    def consume_tokens(self, tokens: int):
        """Record token consumption."""
        self.tokens_consumed += tokens
        
    def record_success(self):
        """Record successful request."""
        self.failure_count = 0
        if self.circuit_open:
            logger.info("Circuit breaker closed after success")
            self.circuit_open = False
    
    def record_failure(self):
        """Record failed request and potentially open circuit."""
        self.failure_count += 1
        
        if self.failure_count >= self.circuit_breaker_threshold:
            if not self.circuit_open:
                logger.error(
                    f"Circuit breaker opened after {self.failure_count} failures"
                )
                self.circuit_open = True
                self.circuit_reset_time = time.time() + 60.0  # Try again in 1 min
    
    def check_circuit_breaker(self):
        """Check if circuit breaker allows requests."""
        if not self.circuit_open:
            return
        
        if time.time() >= self.circuit_reset_time:
            logger.info("Circuit breaker attempting auto-reset")
            self.circuit_open = False
            self.failure_count = 0
            return
        
        raise CircuitBreakerOpen(
            f"Circuit breaker open due to {self.failure_count} failures. "
            f"Retry after {self.circuit_reset_time - time.time():.1f}s"
        )
```

## Implementation Tasks

### Phase 1: Async Routing Engine
- [ ] Implement `AsyncRoutingEngine` with lock-protected embedding
- [ ] Add similarity matrix computation
- [ ] Implement graph construction with threshold filtering
- [ ] Add cycle detection and breaking
- [ ] Test with 4, 8, 12 agent swarms
- [ ] Benchmark routing pipeline latency

### Phase 2: Delegation System
- [ ] Implement `DelegationManager` with depth limits
- [ ] Add mini-swarm creation logic
- [ ] Implement timeout and backpressure
- [ ] Add delegation tree tracking
- [ ] Test nested delegation (depth 0, 1, 2)
- [ ] Test delegation timeout handling

### Phase 3: Message Routing
- [ ] Implement `MessageRouter` with topological ordering
- [ ] Add message history pruning
- [ ] Build message context formatting
- [ ] Test message routing correctness
- [ ] Verify no duplicate messages
- [ ] Test with complex graph topologies

### Phase 4: Performance Safeguards
- [ ] Implement rate limiting (requests per minute)
- [ ] Add token budget enforcement
- [ ] Build circuit breaker pattern
- [ ] Test budget exhaustion handling
- [ ] Test circuit breaker auto-reset
- [ ] Add safeguard bypass for testing

### Phase 5: Integration
- [ ] Integrate routing engine with orchestrator
- [ ] Connect delegation manager
- [ ] Wire up message router
- [ ] Add performance safeguards to all paths
- [ ] End-to-end integration test
- [ ] Performance regression test

## Delegation Strategy
You may delegate to sub-Claudes:
- **Routing Algorithm** - Implement similarity + graph construction
- **Cycle Breaking** - Implement cycle detection and removal
- **Delegation Logic** - Build mini-swarm creation
- **Message Protocol** - Implement message routing
- **Safeguards** - Build rate limiter and circuit breaker

## Success Criteria
✅ Routing graph built in <1s for 8 agents
✅ Cycle detection finds and breaks all cycles
✅ Delegations respect depth and concurrency limits
✅ Messages route correctly according to graph edges
✅ Token budget prevents runaway consumption
✅ Rate limiter enforces max RPM
✅ Circuit breaker opens on repeated failures
✅ All components have comprehensive unit tests

## Testing Requirements
1. **Routing Tests**: 
   - Empty descriptors
   - Single agent
   - Disconnected graph
   - Fully connected graph
   - Cyclic graph

2. **Delegation Tests**:
   - Single delegation
   - Concurrent delegations
   - Nested delegation (depth 2)
   - Delegation timeout
   - Delegation failure

3. **Message Tests**:
   - No edges (no messages)
   - Linear chain (sequential messages)
   - Fork (broadcast messages)
   - Join (multiple senders)

4. **Safeguard Tests**:
   - Rate limit enforcement
   - Token budget exhaustion
   - Circuit breaker trigger
   - Circuit breaker auto-reset

## Files to Create/Modify
- `src/routing/async_engine.py` - Async routing implementation
- `src/delegation/manager.py` - Delegation system
- `src/messaging/router.py` - Message routing protocol
- `src/safeguards/limits.py` - Performance safeguards
- `tests/test_routing.py` - Routing tests
- `tests/test_delegation.py` - Delegation tests
- `tests/test_messaging.py` - Message tests
- `tests/test_safeguards.py` - Safeguard tests

## Constraints
- NO unbounded loops (always use max iterations)
- NO silent delegation failures (always log + return error)
- NO message routing without graph validation
- NO token consumption without budget check
- NO rate limit bypass in production code

## Integration Points with Opus Lead
Your work depends on:
- `AsyncDyTopoOrchestrator` base class
- `_call_with_retry` method for LLM calls
- `ExecutionMetrics` for tracking
- vLLM async client setup

You provide to Sonnet Lead #2:
- Routing graph structure
- Delegation API
- Message routing data
- Performance metrics

## Final Deliverable
Provide:
1. **Summary** of routing and delegation architecture
2. **Code diffs** for key components
3. **Test coverage report** (target >90%)
4. **Performance metrics** (routing latency, delegation overhead)
5. **Known edge cases** and handling strategy

Remember: Your routing and delegation layer enables the swarm's intelligence. Make it fast, safe, and deterministic.
