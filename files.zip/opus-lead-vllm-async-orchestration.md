# Claude Code Prompt: Opus Lead - vLLM Async Orchestration Architecture

## Your Role
You are the **Architectural Lead** for a fundamental transformation: migrating a sequential DyTopo multi-agent swarm from LM Studio single-request execution to **high-throughput async inference powered by vLLM**. You will design the async orchestration architecture, implement vLLM integration, and establish the async execution foundation that enables true parallel agent reasoning.

## Context: The Transformation
**Current State:**
- Sequential agent execution (one LLM call at a time)
- LM Studio backend at `localhost:1234` 
- ~3-8 minutes per 4-agent, 3-round swarm
- Blocking descriptor generation and agent execution
- No concurrency because single-GPU processes one request at a time

**Target State:**
- vLLM inference server with async batch processing
- Multiple agents executing truly in parallel
- DyTopo routing fanning out concurrent inference calls
- Task delegation, retries, critiques become cheap and scalable
- Deterministic convergence with explicit termination

**Your Scope:**
1. **vLLM Integration** - Replace LM Studio with vLLM OpenAI-compatible API
2. **Async Orchestration Core** - Transform `DyTopoOrchestrator` to async-first
3. **Concurrent Execution Model** - Parallel descriptor generation & agent execution
4. **Inference Scheduling** - Concurrency limits, token budgets, retry logic
5. **Architecture Documentation** - Update system design docs

## Critical Requirements

### 1. vLLM Server Configuration
**Inference Server Setup:**
```python
# Expected vLLM server invocation (document this):
# vllm serve Qwen/Qwen3-30B-A3B-Instruct-2507 \
#   --port 8000 \
#   --max-model-len 80000 \
#   --gpu-memory-utilization 0.95 \
#   --max-num-batched-tokens 81920 \
#   --max-num-seqs 32 \
#   --enable-prefix-caching \
#   --disable-log-requests

# OpenAI-compatible endpoint: http://localhost:8000/v1
```

**Client Configuration:**
- Use `openai.AsyncOpenAI` with base_url pointing to vLLM
- Connection pooling: max 16 concurrent connections
- Timeout strategy: connect=10s, read=180s (long generation), write=10s
- Retry logic: exponential backoff with max 3 attempts
- Rate limiting: configurable max concurrent requests (default 8)

### 2. Async Orchestrator Architecture

**Core Class Transformation:**
```python
import asyncio
from openai import AsyncOpenAI
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass
import time

class AsyncDyTopoOrchestrator:
    """
    Fully async multi-agent orchestrator with parallel execution.
    
    Key Design Principles:
    - All LLM calls are async and can run concurrently
    - Routing graph determines execution order, but within a tier agents run in parallel
    - Semaphore controls max concurrent inference requests
    - Each agent maintains independent conversation history
    - Manager can terminate at any round
    """
    
    def __init__(
        self,
        agents: List[Agent],
        manager: ManagerAgent,
        embedder,  # sentence-transformers model for routing
        vllm_base_url: str = "http://localhost:8000/v1",
        tau: float = 0.3,
        K_in: int = 3,
        T_max: int = 5,
        max_concurrent: int = 8,
        token_budget_per_agent: int = 4096,
    ):
        self.agents = {a.id: a for a in agents}
        self.manager = manager
        self.embedder = embedder
        self.tau = tau
        self.K_in = K_in
        self.T_max = T_max
        
        # vLLM async client
        self.client = AsyncOpenAI(
            base_url=vllm_base_url,
            api_key="EMPTY",  # vLLM doesn't need API key
            max_retries=3,
            timeout=httpx.Timeout(connect=10.0, read=180.0, write=10.0)
        )
        
        # Concurrency control
        self.inference_semaphore = asyncio.Semaphore(max_concurrent)
        self.token_budget = token_budget_per_agent
        
        # State tracking
        self.metrics = ExecutionMetrics()
        self.round_history: List[RoundRecord] = []
        
    async def run(
        self,
        task: str,
        on_progress: Optional[Callable] = None
    ) -> SwarmResult:
        """
        Execute full DyTopo loop with async parallelization.
        
        Execution Pattern Per Round:
        1. Manager determines goal (async single call)
        2. Descriptor generation (parallel async calls)
        3. Routing computation (CPU-bound, single-threaded)
        4. Agent execution in topological order tiers (parallel within tier)
        5. State accumulation
        
        Returns SwarmResult with full trace.
        """
        start_time = time.monotonic()
        
        for round_num in range(1, self.T_max + 1):
            if on_progress:
                await on_progress("round_start", {"round": round_num})
            
            # Phase 1: Manager goal (single async call)
            manager_result = await self._call_manager(task, self.round_history)
            
            if manager_result.get("terminate", False):
                return self._build_result(
                    task=task,
                    termination="manager_halt",
                    final_answer=manager_result.get("final_answer"),
                    elapsed=time.monotonic() - start_time
                )
            
            round_goal = manager_result["goal"]
            
            # Phase 2: Descriptor generation (PARALLEL async calls)
            descriptors = await self._generate_descriptors_parallel(
                round_goal, 
                self.round_history,
                on_progress
            )
            
            # Phase 3: Routing (CPU-bound, synchronous)
            routing_graph = self._build_routing_graph(descriptors)
            execution_tiers = self._compute_execution_tiers(routing_graph)
            
            # Phase 4: Agent execution (parallel within tiers)
            outputs = await self._execute_agents_by_tiers(
                execution_tiers,
                routing_graph,
                round_goal,
                on_progress
            )
            
            # Phase 5: Record round state
            self.round_history.append(RoundRecord(
                round_number=round_num,
                goal=round_goal,
                descriptors=descriptors,
                routing_graph=routing_graph,
                outputs=outputs,
                metrics=self.metrics.snapshot()
            ))
        
        return self._build_result(
            task=task,
            termination="max_rounds",
            final_answer=self._synthesize_final_answer(),
            elapsed=time.monotonic() - start_time
        )
    
    async def _generate_descriptors_parallel(
        self,
        goal: str,
        history: List[RoundRecord],
        on_progress: Optional[Callable]
    ) -> Dict[str, Descriptor]:
        """
        Generate descriptors for all agents in parallel.
        
        This is a key parallelization point:
        - Previously: 4 sequential calls = 12-20s
        - Now: 4 parallel calls = 3-5s (limited by slowest)
        """
        async def get_descriptor(agent_id: str, agent: Agent):
            desc = await self._call_for_descriptor(agent, goal, history)
            if on_progress:
                await on_progress("descriptor", {
                    "agent": agent_id,
                    "descriptor": desc
                })
            return agent_id, desc
        
        # Launch all descriptor calls concurrently
        tasks = [
            get_descriptor(agent_id, agent)
            for agent_id, agent in self.agents.items()
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Handle failures gracefully
        descriptors = {}
        for result in results:
            if isinstance(result, Exception):
                # Log error, use fallback descriptor
                logger.error(f"Descriptor generation failed: {result}")
                continue
            agent_id, desc = result
            descriptors[agent_id] = desc
        
        return descriptors
    
    async def _execute_agents_by_tiers(
        self,
        tiers: List[List[str]],  # e.g., [[ProblemParser], [Solver, Verifier], [Critic]]
        graph: nx.DiGraph,
        goal: str,
        on_progress: Optional[Callable]
    ) -> Dict[str, str]:
        """
        Execute agents in topological order, parallelizing within tiers.
        
        Key insight: Agents in the same tier have no dependencies on each other,
        so they can run truly in parallel.
        """
        all_outputs = {}
        
        for tier_idx, tier in enumerate(tiers):
            if on_progress:
                await on_progress("tier_start", {
                    "tier": tier_idx,
                    "agents": tier
                })
            
            # Execute all agents in this tier concurrently
            async def execute_agent(agent_id: str):
                agent = self.agents[agent_id]
                incoming = self._collect_incoming_messages(agent_id, graph, all_outputs)
                
                output = await self._call_agent_for_work(
                    agent,
                    goal,
                    incoming,
                    self.round_history
                )
                
                if on_progress:
                    await on_progress("agent_complete", {
                        "agent": agent_id,
                        "output_length": len(output)
                    })
                
                return agent_id, output
            
            tier_tasks = [execute_agent(aid) for aid in tier]
            tier_results = await asyncio.gather(*tier_tasks, return_exceptions=True)
            
            # Accumulate results
            for result in tier_results:
                if isinstance(result, Exception):
                    logger.error(f"Agent execution failed: {result}")
                    continue
                agent_id, output = result
                all_outputs[agent_id] = output
        
        return all_outputs
    
    async def _call_with_retry(
        self,
        system: str,
        user: str,
        **kwargs
    ) -> Tuple[str, Dict]:
        """
        Async LLM call with semaphore-controlled concurrency and retry logic.
        
        Concurrency Safety:
        - Semaphore ensures max_concurrent limit respected
        - Each call is independent, no shared mutable state
        - Timeouts prevent hung requests blocking queue
        """
        async with self.inference_semaphore:
            for attempt in range(1, 4):  # max 3 attempts
                try:
                    start = time.monotonic()
                    
                    response = await self.client.chat.completions.create(
                        model="Qwen/Qwen3-30B-A3B-Instruct-2507",
                        messages=[
                            {"role": "system", "content": system},
                            {"role": "user", "content": user}
                        ],
                        temperature=kwargs.get("temperature", 0.7),
                        max_tokens=kwargs.get("max_tokens", self.token_budget),
                        top_p=0.85,
                        **kwargs
                    )
                    
                    elapsed = time.monotonic() - start
                    content = response.choices[0].message.content
                    usage = {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens
                    }
                    
                    self.metrics.record_call(elapsed, usage)
                    
                    return content, usage
                    
                except asyncio.TimeoutError:
                    logger.warning(f"LLM timeout on attempt {attempt}/3")
                    if attempt == 3:
                        raise
                    await asyncio.sleep(2 ** attempt)  # exponential backoff
                    
                except Exception as e:
                    logger.error(f"LLM error on attempt {attempt}/3: {e}")
                    if attempt == 3:
                        raise
                    await asyncio.sleep(2 ** attempt)
        
        raise RuntimeError("_call_with_retry exhausted retries")
    
    def _compute_execution_tiers(self, graph: nx.DiGraph) -> List[List[str]]:
        """
        Compute topological tiers for parallel execution.
        
        Returns: [[tier0_agents], [tier1_agents], ...]
        where all agents in tier N can execute in parallel.
        """
        # Use networkx topological_generations
        tiers = list(nx.topological_generations(graph))
        return tiers
```

### 3. Deterministic Workflow Design

**Manager Termination Logic:**
```python
async def _call_manager(
    self,
    task: str,
    history: List[RoundRecord]
) -> Dict[str, Any]:
    """
    Manager determines next goal or terminates swarm.
    
    Termination Conditions (explicit):
    1. Goal achieved with high confidence
    2. Agents converged on answer
    3. No progress in last 2 rounds
    4. Critical error detected
    
    NO emergent chatter - structured decision only.
    """
    system = """You are the Manager agent coordinating a multi-agent reasoning swarm.
    
Your role: Analyze progress and decide next action.

Output JSON with exactly these fields:
{
  "terminate": bool,  // true if task is complete
  "goal": str,        // next round goal (empty if terminate)
  "reasoning": str,   // brief justification
  "final_answer": str // only if terminate=true
}

Terminate when:
- Agents produced correct, verified solution
- Multiple agents converged on same answer
- No new information in last 2 rounds
- Critical error prevents progress

Do NOT terminate prematurely. Err on side of one more round if uncertain.
"""
    
    user = self._build_manager_context(task, history)
    
    response, _ = await self._call_with_retry(system, user, temperature=0.3)
    
    try:
        parsed = json.loads(response)
        return parsed
    except json.JSONDecodeError:
        # Fallback: don't terminate on parse error
        logger.error(f"Manager JSON parse failed: {response}")
        return {
            "terminate": False,
            "goal": "Continue investigation",
            "reasoning": "JSON parse failed, continuing"
        }
```

### 4. Observability Integration Points

**Metrics Collection:**
```python
@dataclass
class ExecutionMetrics:
    """Per-swarm execution metrics."""
    total_calls: int = 0
    total_tokens: int = 0
    total_latency: float = 0.0
    per_agent_latency: Dict[str, List[float]] = field(default_factory=dict)
    per_round_latency: List[float] = field(default_factory=list)
    failures: List[Dict] = field(default_factory=list)
    
    def record_call(self, latency: float, usage: Dict):
        self.total_calls += 1
        self.total_tokens += usage["total_tokens"]
        self.total_latency += latency
    
    def record_failure(self, agent: str, error: str, attempt: int):
        self.failures.append({
            "agent": agent,
            "error": error,
            "attempt": attempt,
            "timestamp": time.time()
        })
    
    def snapshot(self) -> Dict:
        return {
            "calls": self.total_calls,
            "tokens": self.total_tokens,
            "avg_latency": self.total_latency / max(1, self.total_calls),
            "failures": len(self.failures)
        }
```

## Implementation Tasks

### Phase 1: vLLM Server Setup
- [ ] Create vLLM server configuration file
- [ ] Document vLLM server invocation command with optimal params
- [ ] Test vLLM concurrent request handling (verify batch processing)
- [ ] Validate OpenAI API compatibility
- [ ] Benchmark throughput: 1, 4, 8, 16 concurrent requests

### Phase 2: Async Client Infrastructure  
- [ ] Implement `AsyncDyTopoOrchestrator` with vLLM client
- [ ] Add semaphore-based concurrency control
- [ ] Implement retry logic with exponential backoff
- [ ] Add timeout handling (connection, read, total)
- [ ] Create connection pool configuration

### Phase 3: Parallel Descriptor Generation
- [ ] Refactor descriptor generation to use `asyncio.gather`
- [ ] Add error handling for individual failures
- [ ] Implement fallback descriptors on failure
- [ ] Add per-agent latency tracking
- [ ] Test with 4, 8, 12 concurrent descriptor calls

### Phase 4: Tiered Agent Execution
- [ ] Implement topological tier computation
- [ ] Parallelize agent execution within tiers
- [ ] Preserve message routing from graph
- [ ] Add tier-level progress reporting
- [ ] Validate execution order correctness

### Phase 5: Deterministic Manager
- [ ] Implement structured manager termination logic
- [ ] Add explicit termination conditions
- [ ] Remove any "broadcast chatter" patterns
- [ ] Add final answer synthesis
- [ ] Test manager decision quality

### Phase 6: Architecture Documentation
- [ ] Update system architecture diagrams
- [ ] Document async flow with sequence diagrams
- [ ] Create vLLM integration guide
- [ ] Document concurrency safety patterns
- [ ] Add troubleshooting guide

## Delegation Strategy
You may delegate to sub-Claudes:
- **vLLM Setup & Benchmarking** - Configure server, run throughput tests
- **Async Client Implementation** - Build retry logic, connection pooling
- **Tier Computation** - Implement topological generation algorithm
- **Manager Logic** - Refactor manager with deterministic termination
- **Documentation** - Create architecture docs and diagrams

## Success Criteria
✅ vLLM server running with documented configuration
✅ AsyncDyTopoOrchestrator passes all unit tests
✅ Descriptor generation completes in <5s for 4 agents (down from 12-20s)
✅ Agent execution respects routing graph dependencies
✅ Concurrency limit prevents resource exhaustion
✅ Manager terminates deterministically
✅ All async calls have timeout protection
✅ Metrics track latency per agent and per round
✅ Documentation explains async architecture clearly

## Testing Requirements
1. **Unit Tests**: Each async method tested in isolation
2. **Integration Test**: Full swarm with 4 agents, 3 rounds
3. **Concurrency Test**: 16 parallel descriptor calls
4. **Failure Test**: Simulate vLLM timeout, verify retry
5. **Determinism Test**: Same task → same routing graph

## Files to Modify
- `src/orchestrator.py` - Main refactor target
- `src/client.py` - vLLM async client
- `src/config.py` - Add vLLM and concurrency config
- `tests/test_async_orchestrator.py` - Async tests
- `docs/architecture/async-swarm-design.md` - New doc
- `docs/operations/vllm-setup.md` - New doc

## Constraints
- NO blocking calls in async context
- NO unbounded concurrency (always use semaphore)
- NO silent failures (log + metric on every error)
- NO undocumented timeouts
- NO JSON parsing without fallback

## Final Deliverable
Provide:
1. **Summary** of architectural changes
2. **Code diff** showing key transformations
3. **vLLM configuration** with optimal params
4. **Benchmark results** (before/after latency)
5. **Architecture documentation** with diagrams
6. **Known issues** and mitigation strategies

Remember: This is the foundation. The other two Claude leads depend on your async infrastructure being solid, well-tested, and observable.
