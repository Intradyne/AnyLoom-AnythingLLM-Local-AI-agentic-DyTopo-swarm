# Parallel Claude Code Execution Guide: vLLM Async Transformation

## Executive Summary

This guide orchestrates the complete transformation of your DyTopo multi-agent swarm from sequential LM Studio execution to high-throughput async inference powered by vLLM. The work is decomposed into **three parallel Claude Code executions** that together deliver a production-ready distributed async reasoning system.

## Transformation Overview

### Current State → Target State

| Aspect | Before | After |
|--------|--------|-------|
| **Inference Backend** | LM Studio (localhost:1234) | vLLM (localhost:8000) |
| **Execution Model** | Sequential agent calls | Parallel async execution |
| **Descriptor Generation** | 12-20s (sequential) | 3-5s (parallel) |
| **Agent Execution** | Sequential by topology | Parallel within tiers |
| **Concurrency** | None (single request) | 8+ concurrent requests |
| **Observability** | Basic logging | Distributed tracing + metrics |
| **Documentation** | Static docs | Living architecture canvas |

### Performance Impact

**Expected Improvements:**
- **Descriptor generation:** 4x faster (parallel async)
- **Agent execution:** 2-3x faster (tiered parallelization)
- **Overall swarm time:** 3-8 minutes → 1-3 minutes
- **Throughput:** 1 swarm at a time → 4+ concurrent swarms

## Three-Lead Parallel Execution Strategy

### Architecture: Work Distribution

```
┌─────────────────────────────────────────────────────────────┐
│                  OPUS LEAD (Architectural)                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │ vLLM Integration + Async Orchestration Core          │  │
│  │ • vLLM server setup & configuration                  │  │
│  │ • AsyncDyTopoOrchestrator implementation            │  │
│  │ • Concurrent descriptor generation                   │  │
│  │ • Tiered agent execution                            │  │
│  │ • Deterministic manager termination                  │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                ┌─────────────┴─────────────┐
                │                           │
┌───────────────▼───────────────┐ ┌────────▼─────────────────────┐
│   SONNET LEAD #1 (Routing)    │ │ SONNET LEAD #2 (Observability)│
│  ┌──────────────────────────┐ │ │  ┌────────────────────────┐  │
│  │ Async Routing Engine     │ │ │  │ Distributed Tracing    │  │
│  │ • Parallel embedding     │ │ │  │ • Trace propagation    │  │
│  │ • Graph construction     │ │ │  │ • Span collection      │  │
│  │ • Cycle detection        │ │ │  │                        │  │
│  └──────────────────────────┘ │ │  │ Metrics Collection     │  │
│  ┌──────────────────────────┐ │ │  │ • Latency tracking     │  │
│  │ Delegation System        │ │ │  │ • Token usage          │  │
│  │ • Concurrent delegation  │ │ │  │ • Error rates          │  │
│  │ • Mini-swarm spawning    │ │ │  │                        │  │
│  │ • Depth limits           │ │ │  │ Performance Profiling  │  │
│  └──────────────────────────┘ │ │  │ • Bottleneck analysis  │  │
│  ┌──────────────────────────┐ │ │  │ • Optimization guide   │  │
│  │ Message Routing          │ │ │  │                        │  │
│  │ • Protocol design        │ │ │  │ Documentation          │  │
│  │ • Message history        │ │ │  │ • overview.canvas      │  │
│  │                          │ │ │  │ • API reference        │  │
│  │ Performance Safeguards   │ │ │  │ • Troubleshooting      │  │
│  │ • Rate limiting          │ │ │  └────────────────────────┘  │
│  │ • Token budgets          │ │ │                              │
│  │ • Circuit breaker        │ │ │                              │
│  └──────────────────────────┘ │ │                              │
└────────────────────────────────┘ └──────────────────────────────┘
```

### Dependencies & Coordination

**Execution Order:**
1. **All three start in parallel** (no blocking dependencies initially)
2. **Sonnet leads may wait** on Opus for:
   - `AsyncDyTopoOrchestrator` base class definition
   - `_call_with_retry` method signature
   - vLLM client configuration
3. **Integration happens at end** when all three are complete

**Communication Protocol:**
- Each Claude Code run operates independently
- Shared interface contracts defined upfront (see below)
- Final integration via shared Git branch

## Interface Contracts (Critical!)

These contracts ensure the three parallel executions integrate cleanly.

### Contract 1: Opus → Sonnet #1

**Opus provides:**
```python
class AsyncDyTopoOrchestrator:
    def __init__(
        self,
        agents: List[Agent],
        manager: ManagerAgent,
        embedder,  # sentence-transformers model
        vllm_base_url: str = "http://localhost:8000/v1",
        tau: float = 0.3,
        K_in: int = 3,
        T_max: int = 5,
        max_concurrent: int = 8,
        token_budget_per_agent: int = 4096,
    ): ...
    
    async def _call_with_retry(
        self,
        system: str,
        user: str,
        **kwargs
    ) -> Tuple[str, Dict]: ...
```

**Sonnet #1 requires:**
- `AsyncDyTopoOrchestrator` base class exists
- `_call_with_retry` returns (content: str, usage: Dict)
- `embedder` is available as instance variable

### Contract 2: Opus → Sonnet #2

**Opus provides:**
```python
@dataclass
class RoundRecord:
    round_number: int
    goal: str
    descriptors: Dict[str, Descriptor]
    routing_graph: nx.DiGraph
    outputs: Dict[str, str]
    metrics: Dict

@dataclass
class SwarmResult:
    task: str
    final_answer: str
    rounds: List[RoundRecord]
    total_tokens: int
    wall_clock_seconds: float
    termination_reason: str
```

**Sonnet #2 requires:**
- Data classes defined with exact field names
- All async methods instrumented for tracing
- Metrics hooks available

### Contract 3: Sonnet #1 → Sonnet #2

**Sonnet #1 provides:**
```python
class AsyncRoutingEngine:
    async def build_routing_graph(
        self,
        descriptors: Dict[str, Descriptor]
    ) -> nx.DiGraph: ...

class DelegationManager:
    async def delegate_task(
        self,
        parent_agent_id: str,
        subtask: str,
        context: Dict,
        depth: int = 0
    ) -> str: ...
```

**Sonnet #2 requires:**
- Routing and delegation methods are async
- Return types match expectations
- Error handling is consistent

## Execution Instructions

### Step 1: Prepare Your Environment

**Create three separate Claude Code sessions:**

```bash
# Terminal 1 - Opus Lead
cd /path/to/your/repo
git checkout -b feature/vllm-async-opus

# Terminal 2 - Sonnet Lead #1
cd /path/to/your/repo
git checkout -b feature/vllm-async-sonnet-1

# Terminal 3 - Sonnet Lead #2
cd /path/to/your/repo
git checkout -b feature/vllm-async-sonnet-2
```

### Step 2: Launch Claude Code Sessions

**Session 1 (Opus):**
```
Load prompt: opus-lead-vllm-async-orchestration.md
Initial directive: "Begin with vLLM server setup and AsyncDyTopoOrchestrator base implementation."
```

**Session 2 (Sonnet #1):**
```
Load prompt: sonnet-lead-1-async-routing-delegation.md
Initial directive: "Start with AsyncRoutingEngine. You can mock orchestrator methods initially."
```

**Session 3 (Sonnet #2):**
```
Load prompt: sonnet-lead-2-observability-performance-docs.md
Initial directive: "Begin with distributed tracing infrastructure. You can instrument dummy methods initially."
```

### Step 3: Monitor Progress

**Create a tracking board:**

| Lead | Phase | Status | Blockers | ETA |
|------|-------|--------|----------|-----|
| Opus | vLLM Setup | In Progress | None | 2h |
| Opus | Async Orchestrator | Not Started | - | 4h |
| Opus | Descriptor Parallel | Not Started | - | 2h |
| Sonnet #1 | Routing Engine | In Progress | None | 3h |
| Sonnet #1 | Delegation | Not Started | - | 3h |
| Sonnet #1 | Message Routing | Not Started | - | 2h |
| Sonnet #2 | Tracing | In Progress | None | 3h |
| Sonnet #2 | Metrics | Not Started | - | 2h |
| Sonnet #2 | Documentation | Not Started | - | 2h |

**Total estimated time:** 8-12 hours of Claude Code execution (can run in parallel)

### Step 4: Integration

**After all three complete:**

```bash
# Merge strategy
git checkout main
git checkout -b feature/vllm-async-integrated

# Merge in order
git merge feature/vllm-async-opus        # Foundation first
git merge feature/vllm-async-sonnet-1    # Routing layer
git merge feature/vllm-async-sonnet-2    # Observability

# Resolve any conflicts (should be minimal with good contracts)
git merge --continue

# Run full integration test
python -m pytest tests/integration/test_async_swarm.py -v
```

### Step 5: Validation

**Critical validation steps:**

1. **vLLM Server Test:**
```bash
# Start vLLM
vllm serve Qwen/Qwen3-30B-A3B-Instruct-2507 \
  --port 8000 \
  --max-model-len 80000 \
  --gpu-memory-utilization 0.95 \
  --max-num-seqs 32

# Test concurrent requests
python scripts/test_vllm_concurrency.py
```

2. **Async Orchestrator Test:**
```python
# Run simple swarm
orchestrator = AsyncDyTopoOrchestrator(...)
result = await orchestrator.run("Prove 1+2+...+(2n-1) = n²")

# Verify:
# - Completion time < 3 minutes
# - All agents executed
# - Manager terminated correctly
```

3. **Routing Test:**
```python
# Test routing graph
engine = AsyncRoutingEngine(embedder, tau=0.3)
graph = await engine.build_routing_graph(descriptors)

# Verify:
# - No cycles (is_directed_acyclic_graph)
# - Edges match expected similarity
# - Topological order valid
```

4. **Observability Test:**
```python
# Check traces
trace_id = trace_id_var.get()
trace = await TraceCollector.get_trace(trace_id)

# Verify:
# - All spans present
# - Hierarchy correct
# - Metrics recorded
```

5. **Documentation Test:**
```bash
# Generate docs
python scripts/generate_docs.py

# Verify:
# - overview-obsidian.canvas exists
# - All nodes and edges present
# - API reference complete
```

## Success Criteria (All Must Pass)

### Functional Requirements
✅ vLLM server runs with documented config
✅ AsyncDyTopoOrchestrator completes full swarm
✅ Descriptor generation parallelizes correctly
✅ Agent execution respects topology
✅ Manager terminates deterministically
✅ Routing graph is valid DAG
✅ Delegation works to depth 2
✅ Message routing preserves order
✅ Rate limiting prevents overload
✅ Token budgets enforce limits
✅ Circuit breaker opens on failures

### Performance Requirements
✅ Descriptor generation < 5s (4 agents)
✅ Full swarm < 3 minutes (was 3-8 min)
✅ Routing computation < 1s (8 agents)
✅ Delegation overhead < 10%
✅ Observability overhead < 10%
✅ Concurrent swarms: 4+ simultaneous

### Observability Requirements
✅ Every async operation traced
✅ Trace export to JSON works
✅ Metrics capture all key operations
✅ Performance profiler identifies bottlenecks
✅ Failure analyzer detects patterns
✅ Documentation auto-generates

### Quality Requirements
✅ Test coverage > 85%
✅ No silent failures (all logged)
✅ No blocking calls in async context
✅ No unbounded concurrency
✅ All public APIs documented

## Known Challenges & Mitigations

### Challenge 1: vLLM Server Stability
**Issue:** vLLM may OOM with too many concurrent requests
**Mitigation:** 
- Set `--max-num-seqs 32` (conservative limit)
- Implement semaphore with max 8 concurrent
- Monitor VRAM with nvidia-smi

### Challenge 2: Async Embedding Model
**Issue:** sentence-transformers not thread-safe
**Mitigation:**
- Use asyncio.Lock to serialize embedding calls
- Run in thread pool via asyncio.to_thread
- Only one embedding call at a time

### Challenge 3: Merge Conflicts
**Issue:** Three parallel implementations may conflict
**Mitigation:**
- Clear interface contracts upfront
- Minimal overlap in file modifications
- Opus lead owns core classes
- Sonnet leads add new files

### Challenge 4: Debugging Async Issues
**Issue:** Async bugs hard to reproduce
**Mitigation:**
- Comprehensive tracing from day 1
- Deterministic test fixtures
- Async-aware debugger (aiomonitor)

### Challenge 5: Documentation Staleness
**Issue:** Docs out of sync with code
**Mitigation:**
- Auto-generate from code
- Enforce doc updates in PR process
- Living canvas updates automatically

## Rollback Plan

If integration fails catastrophically:

1. **Revert to main branch**
```bash
git checkout main
```

2. **Preserve work for later**
```bash
git checkout -b feature/vllm-async-paused
git merge feature/vllm-async-integrated --no-commit
# Save state for future retry
```

3. **Continue with LM Studio**
- Keep sequential execution
- Apply observability layer only
- Retry vLLM migration later

## Post-Integration Tasks

After successful merge:

### Week 1: Stabilization
- [ ] Run swarm benchmarks (compare to baseline)
- [ ] Monitor vLLM memory usage
- [ ] Tune concurrency limits
- [ ] Optimize hot paths identified by profiler
- [ ] Fix any edge case bugs

### Week 2: Documentation
- [ ] Update all README files
- [ ] Record demo video of async swarm
- [ ] Write blog post on migration
- [ ] Create troubleshooting runbook
- [ ] Update architectural diagrams

### Week 3: Advanced Features
- [ ] Implement adaptive concurrency (scale with VRAM)
- [ ] Add A/B testing framework (vLLM vs LM Studio)
- [ ] Build multi-GPU support
- [ ] Optimize routing algorithm
- [ ] Add swarm-level caching

### Ongoing: Optimization
- [ ] Profile every month
- [ ] Track performance regression
- [ ] Optimize based on real usage
- [ ] Update documentation continuously

## Final Checklist

Before declaring victory:

**Infrastructure:**
- [ ] vLLM server runs reliably
- [ ] Concurrent requests don't OOM
- [ ] Backup plan (LM Studio) still works

**Code Quality:**
- [ ] All tests passing
- [ ] Coverage > 85%
- [ ] No linter errors
- [ ] Type hints complete

**Performance:**
- [ ] Swarm time improved by 2-3x
- [ ] Throughput increased by 4x
- [ ] No performance regressions

**Observability:**
- [ ] Traces exported successfully
- [ ] Metrics dashboard deployed
- [ ] Failure alerts configured

**Documentation:**
- [ ] overview-obsidian.canvas generated
- [ ] API reference complete
- [ ] Troubleshooting guide written
- [ ] Runbook tested

**Operations:**
- [ ] Monitoring in place
- [ ] Rollback plan tested
- [ ] On-call runbook ready

---

## Conclusion

This is an ambitious transformation: sequential → parallel, single backend → vLLM, no observability → comprehensive tracing. The three-lead parallel execution strategy is designed to:

1. **Maximize velocity** - Work proceeds in parallel
2. **Minimize risk** - Clear interface contracts prevent conflicts
3. **Enable quality** - Each lead focuses on excellence in their domain
4. **Ensure completeness** - All aspects covered (infrastructure + routing + observability)

**Estimated total time:** 8-12 hours of Claude Code execution, plus 2-4 hours of integration and validation.

**Expected outcome:** A production-ready distributed async reasoning system that is 2-3x faster, 4x more scalable, and fully observable.

Ready to begin? Start all three Claude Code sessions and watch the transformation happen in parallel. Good luck! 🚀
