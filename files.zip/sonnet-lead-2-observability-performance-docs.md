# Claude Code Prompt: Sonnet Lead #2 - Observability, Performance & Documentation

## Your Role
You are **Implementation Lead** for observability, performance optimization, and documentation. You will instrument the async swarm with comprehensive tracing and metrics, optimize bottlenecks identified through profiling, and create the living documentation architecture that makes this complex system understandable and maintainable.

## Context: Why This Matters
In a distributed async system with 8+ agents running concurrently, making 50+ LLM calls per swarm, the **#1 failure mode** is opacity. When something goes wrong, you need:
- Which agent failed and why
- What the routing graph looked like
- Where time was spent
- What the performance bottleneck was
- How to reproduce the issue

Without observability, debugging is archaeology. Your job is to make the system **transparent and debuggable**.

## Your Scope
1. **Distributed Tracing** - Request tracing across async calls
2. **Metrics Collection** - Latency, tokens, failures per agent/round
3. **Performance Profiling** - Identify and optimize bottlenecks
4. **Failure Analysis** - Detailed error tracking and recovery
5. **Documentation Architecture** - Living docs with auto-generated visuals

## Critical Architecture Patterns

### 1. Distributed Tracing System

**Trace Propagation:**
```python
import uuid
from contextvars import ContextVar
from typing import Optional, Dict, List
import time
import json
from pathlib import Path

# Global context vars for trace propagation
trace_id_var: ContextVar[Optional[str]] = ContextVar("trace_id", default=None)
span_stack_var: ContextVar[List[str]] = ContextVar("span_stack", default=[])

@dataclass
class Span:
    """A single unit of work in distributed trace."""
    span_id: str
    parent_id: Optional[str]
    trace_id: str
    operation: str
    start_time: float
    end_time: Optional[float] = None
    status: str = "in_progress"  # in_progress | success | error
    metadata: Dict = field(default_factory=dict)
    
    def __post_init__(self):
        if self.span_id is None:
            self.span_id = uuid.uuid4().hex[:16]
    
    def finish(self, status: str = "success", **metadata):
        """Mark span complete."""
        self.end_time = time.time()
        self.status = status
        self.metadata.update(metadata)
    
    @property
    def duration(self) -> Optional[float]:
        """Duration in seconds."""
        if self.end_time is None:
            return None
        return self.end_time - self.start_time
    
    def to_dict(self) -> Dict:
        """Serialize for logging."""
        return {
            "span_id": self.span_id,
            "parent_id": self.parent_id,
            "trace_id": self.trace_id,
            "operation": self.operation,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "status": self.status,
            "metadata": self.metadata
        }

class TraceContext:
    """
    Context manager for distributed tracing.
    
    Usage:
        async with TraceContext("agent_execution", agent_id=agent_id):
            result = await execute_agent()
    """
    
    def __init__(self, operation: str, **metadata):
        self.operation = operation
        self.metadata = metadata
        self.span: Optional[Span] = None
        
    async def __aenter__(self):
        # Get or create trace ID
        trace_id = trace_id_var.get()
        if trace_id is None:
            trace_id = uuid.uuid4().hex
            trace_id_var.set(trace_id)
        
        # Get parent span from stack
        span_stack = span_stack_var.get()
        parent_id = span_stack[-1] if span_stack else None
        
        # Create new span
        self.span = Span(
            span_id=uuid.uuid4().hex[:16],
            parent_id=parent_id,
            trace_id=trace_id,
            operation=self.operation,
            start_time=time.time(),
            metadata=self.metadata
        )
        
        # Push to stack
        new_stack = span_stack + [self.span.span_id]
        span_stack_var.set(new_stack)
        
        # Log span start
        logger.debug(f"[TRACE] Started {self.operation} (span={self.span.span_id})")
        
        return self.span
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        # Pop from stack
        span_stack = span_stack_var.get()
        if span_stack:
            span_stack_var.set(span_stack[:-1])
        
        # Finish span
        if exc_type is not None:
            self.span.finish(
                status="error",
                error_type=exc_type.__name__,
                error_message=str(exc_val)
            )
        else:
            self.span.finish(status="success")
        
        # Log span completion
        logger.debug(
            f"[TRACE] Finished {self.operation} "
            f"({self.span.duration:.3f}s, {self.span.status})"
        )
        
        # Record to trace collector
        TraceCollector.record(self.span)
        
        return False  # Don't suppress exceptions

class TraceCollector:
    """
    Collects and stores trace spans for analysis.
    
    Provides:
    - In-memory trace storage
    - JSON export for external analysis
    - Query API for debugging
    """
    
    _spans: Dict[str, List[Span]] = {}  # trace_id -> [spans]
    _lock = asyncio.Lock()
    
    @classmethod
    async def record(cls, span: Span):
        """Record a completed span."""
        async with cls._lock:
            if span.trace_id not in cls._spans:
                cls._spans[span.trace_id] = []
            cls._spans[span.trace_id].append(span)
    
    @classmethod
    async def get_trace(cls, trace_id: str) -> List[Span]:
        """Get all spans for a trace."""
        async with cls._lock:
            return cls._spans.get(trace_id, [])
    
    @classmethod
    async def export_trace(cls, trace_id: str, output_path: Path):
        """Export trace to JSON."""
        spans = await cls.get_trace(trace_id)
        
        trace_data = {
            "trace_id": trace_id,
            "total_spans": len(spans),
            "spans": [s.to_dict() for s in spans]
        }
        
        output_path.write_text(json.dumps(trace_data, indent=2))
    
    @classmethod
    async def analyze_trace(cls, trace_id: str) -> Dict:
        """Analyze trace for bottlenecks."""
        spans = await cls.get_trace(trace_id)
        
        # Aggregate by operation
        operation_stats = {}
        for span in spans:
            op = span.operation
            if op not in operation_stats:
                operation_stats[op] = {
                    "count": 0,
                    "total_duration": 0.0,
                    "errors": 0
                }
            
            operation_stats[op]["count"] += 1
            if span.duration:
                operation_stats[op]["total_duration"] += span.duration
            if span.status == "error":
                operation_stats[op]["errors"] += 1
        
        # Calculate averages
        for op, stats in operation_stats.items():
            if stats["count"] > 0:
                stats["avg_duration"] = stats["total_duration"] / stats["count"]
        
        return {
            "trace_id": trace_id,
            "total_spans": len(spans),
            "operation_stats": operation_stats,
            "total_duration": max(s.end_time for s in spans if s.end_time) - 
                             min(s.start_time for s in spans)
        }
```

**Usage in Orchestrator:**
```python
class AsyncDyTopoOrchestrator:
    async def run(self, task: str, ...) -> SwarmResult:
        # Create new trace for this swarm
        trace_id = uuid.uuid4().hex
        trace_id_var.set(trace_id)
        
        async with TraceContext("swarm_execution", task=task):
            for round_num in range(1, self.T_max + 1):
                async with TraceContext("round", round_num=round_num):
                    
                    # Manager call
                    async with TraceContext("manager_call"):
                        manager_result = await self._call_manager(...)
                    
                    # Descriptor generation (parallel)
                    async with TraceContext("descriptor_generation"):
                        descriptors = await self._generate_descriptors_parallel(...)
                    
                    # Routing
                    async with TraceContext("routing"):
                        graph = await self.routing_engine.build_routing_graph(...)
                    
                    # Agent execution
                    async with TraceContext("agent_execution"):
                        outputs = await self._execute_agents_by_tiers(...)
        
        # Export trace
        await TraceCollector.export_trace(
            trace_id,
            Path(f"traces/swarm_{trace_id}.json")
        )
        
        return result
```

### 2. Comprehensive Metrics Collection

**Metric Types:**
```python
from dataclasses import dataclass, field
from typing import List, Dict
import statistics

@dataclass
class MetricPoint:
    """Single metric observation."""
    name: str
    value: float
    timestamp: float
    labels: Dict[str, str] = field(default_factory=dict)

class MetricsCollector:
    """
    Collects and aggregates metrics for analysis.
    
    Metric Categories:
    1. Latency - Duration of operations
    2. Throughput - Requests/tokens per second
    3. Errors - Failure counts and rates
    4. Resources - Token usage, memory
    """
    
    def __init__(self):
        self._metrics: List[MetricPoint] = []
        self._lock = asyncio.Lock()
    
    async def record(self, name: str, value: float, **labels):
        """Record a metric point."""
        async with self._lock:
            self._metrics.append(MetricPoint(
                name=name,
                value=value,
                timestamp=time.time(),
                labels=labels
            ))
    
    async def get_stats(self, name: str, **filter_labels) -> Dict:
        """Get statistics for a metric."""
        async with self._lock:
            # Filter metrics
            matching = [
                m for m in self._metrics
                if m.name == name and
                all(m.labels.get(k) == v for k, v in filter_labels.items())
            ]
            
            if not matching:
                return {}
            
            values = [m.value for m in matching]
            
            return {
                "count": len(values),
                "sum": sum(values),
                "min": min(values),
                "max": max(values),
                "mean": statistics.mean(values),
                "median": statistics.median(values),
                "p95": self._percentile(values, 0.95),
                "p99": self._percentile(values, 0.99)
            }
    
    def _percentile(self, values: List[float], p: float) -> float:
        """Calculate percentile."""
        sorted_values = sorted(values)
        index = int(len(sorted_values) * p)
        return sorted_values[min(index, len(sorted_values) - 1)]
    
    async def export_prometheus(self, output_path: Path):
        """Export metrics in Prometheus format."""
        async with self._lock:
            lines = []
            
            # Group by metric name
            by_name = {}
            for m in self._metrics:
                if m.name not in by_name:
                    by_name[m.name] = []
                by_name[m.name].append(m)
            
            # Format each metric
            for name, points in by_name.items():
                lines.append(f"# TYPE {name} gauge")
                for p in points:
                    label_str = ",".join(f'{k}="{v}"' for k, v in p.labels.items())
                    lines.append(f"{name}{{{label_str}}} {p.value} {int(p.timestamp*1000)}")
            
            output_path.write_text("\n".join(lines))

# Global metrics collector
metrics = MetricsCollector()

# Usage in orchestrator
async def _call_with_retry(self, ...):
    start = time.time()
    
    try:
        result = await self.client.chat.completions.create(...)
        
        # Record latency
        await metrics.record(
            "llm_call_duration_seconds",
            time.time() - start,
            agent=agent_id,
            status="success"
        )
        
        # Record tokens
        await metrics.record(
            "llm_tokens_total",
            result.usage.total_tokens,
            agent=agent_id,
            token_type="total"
        )
        
        return result
        
    except Exception as e:
        await metrics.record(
            "llm_call_duration_seconds",
            time.time() - start,
            agent=agent_id,
            status="error"
        )
        
        await metrics.record(
            "llm_errors_total",
            1,
            agent=agent_id,
            error_type=type(e).__name__
        )
        
        raise
```

### 3. Performance Profiling & Optimization

**Profiling Infrastructure:**
```python
import cProfile
import pstats
from io import StringIO

class PerformanceProfiler:
    """
    Profile swarm execution to identify bottlenecks.
    
    Two modes:
    1. Statistical profiling - cProfile for CPU time
    2. Async profiling - Custom instrumentation for async ops
    """
    
    def __init__(self):
        self.profiler = None
        self.async_timings: Dict[str, List[float]] = {}
    
    async def profile_swarm(
        self,
        orchestrator: AsyncDyTopoOrchestrator,
        task: str
    ) -> Dict:
        """
        Profile a full swarm execution.
        
        Returns comprehensive performance report.
        """
        # Start CPU profiler
        self.profiler = cProfile.Profile()
        self.profiler.enable()
        
        # Run swarm
        start_time = time.time()
        result = await orchestrator.run(task)
        wall_time = time.time() - start_time
        
        # Stop profiler
        self.profiler.disable()
        
        # Analyze CPU profile
        s = StringIO()
        ps = pstats.Stats(self.profiler, stream=s)
        ps.sort_stats("cumulative")
        ps.print_stats(20)  # Top 20 functions
        
        cpu_profile = s.getvalue()
        
        # Analyze async timings
        async_analysis = await self._analyze_async_timings()
        
        # Get trace analysis
        trace_analysis = await TraceCollector.analyze_trace(
            trace_id_var.get()
        )
        
        return {
            "wall_time": wall_time,
            "cpu_profile": cpu_profile,
            "async_analysis": async_analysis,
            "trace_analysis": trace_analysis,
            "result": result
        }
    
    async def _analyze_async_timings(self) -> Dict:
        """Analyze async operation timings."""
        analysis = {}
        
        for operation, timings in self.async_timings.items():
            if not timings:
                continue
                
            analysis[operation] = {
                "count": len(timings),
                "total": sum(timings),
                "mean": statistics.mean(timings),
                "min": min(timings),
                "max": max(timings),
                "p95": self._percentile(timings, 0.95)
            }
        
        return analysis

class BottleneckAnalyzer:
    """
    Analyze traces and metrics to identify bottlenecks.
    
    Provides actionable recommendations.
    """
    
    @staticmethod
    async def analyze(trace_id: str) -> Dict:
        """
        Analyze trace for performance issues.
        
        Returns:
        - Identified bottlenecks
        - Optimization recommendations
        - Performance score
        """
        trace = await TraceCollector.get_trace(trace_id)
        
        # Find slowest operations
        slow_ops = sorted(
            [s for s in trace if s.duration],
            key=lambda s: s.duration,
            reverse=True
        )[:10]
        
        # Calculate parallelization opportunity
        total_sequential = sum(s.duration for s in trace if s.duration)
        total_wall = max(s.end_time for s in trace) - min(s.start_time for s in trace)
        parallelization_factor = total_sequential / total_wall
        
        # Identify long-pole operations (blocking parallel progress)
        long_poles = []
        for span in trace:
            if span.duration and span.duration > 10.0:  # >10s is significant
                long_poles.append({
                    "operation": span.operation,
                    "duration": span.duration,
                    "metadata": span.metadata
                })
        
        # Generate recommendations
        recommendations = []
        
        if parallelization_factor < 2.0:
            recommendations.append({
                "priority": "high",
                "category": "parallelization",
                "message": f"Low parallelization factor ({parallelization_factor:.1f}x). "
                          "Consider increasing concurrent execution."
            })
        
        if long_poles:
            recommendations.append({
                "priority": "high",
                "category": "long_poles",
                "message": f"Found {len(long_poles)} operations >10s. "
                          "These block parallel progress.",
                "details": long_poles
            })
        
        # Check for repeated operations
        op_counts = {}
        for span in trace:
            op_counts[span.operation] = op_counts.get(span.operation, 0) + 1
        
        high_frequency = {op: count for op, count in op_counts.items() if count > 20}
        if high_frequency:
            recommendations.append({
                "priority": "medium",
                "category": "caching",
                "message": f"High-frequency operations detected: {high_frequency}. "
                          "Consider caching.",
            })
        
        return {
            "trace_id": trace_id,
            "total_duration": total_wall,
            "parallelization_factor": parallelization_factor,
            "slowest_operations": [
                {"op": s.operation, "duration": s.duration}
                for s in slow_ops
            ],
            "long_poles": long_poles,
            "recommendations": recommendations,
            "performance_score": min(100, int(parallelization_factor * 30))
        }
```

### 4. Failure Analysis & Recovery

**Failure Tracking:**
```python
@dataclass
class FailureRecord:
    """Record of a failure event."""
    failure_id: str
    timestamp: float
    component: str
    operation: str
    error_type: str
    error_message: str
    trace_id: str
    span_id: str
    context: Dict
    recovered: bool = False
    recovery_strategy: Optional[str] = None

class FailureAnalyzer:
    """
    Tracks and analyzes failures for debugging and recovery.
    
    Capabilities:
    - Failure pattern detection
    - Root cause analysis
    - Recovery strategy suggestions
    - Failure rate monitoring
    """
    
    def __init__(self):
        self._failures: List[FailureRecord] = []
        self._lock = asyncio.Lock()
    
    async def record_failure(
        self,
        component: str,
        operation: str,
        error: Exception,
        **context
    ) -> str:
        """Record a failure event."""
        failure_id = uuid.uuid4().hex[:12]
        
        record = FailureRecord(
            failure_id=failure_id,
            timestamp=time.time(),
            component=component,
            operation=operation,
            error_type=type(error).__name__,
            error_message=str(error),
            trace_id=trace_id_var.get() or "unknown",
            span_id=span_stack_var.get()[-1] if span_stack_var.get() else "unknown",
            context=context
        )
        
        async with self._lock:
            self._failures.append(record)
        
        logger.error(
            f"[FAILURE] {component}.{operation} failed: {error} "
            f"(failure_id={failure_id})"
        )
        
        return failure_id
    
    async def mark_recovered(self, failure_id: str, strategy: str):
        """Mark a failure as recovered."""
        async with self._lock:
            for record in self._failures:
                if record.failure_id == failure_id:
                    record.recovered = True
                    record.recovery_strategy = strategy
                    break
    
    async def analyze_patterns(self) -> Dict:
        """Analyze failure patterns."""
        async with self._lock:
            if not self._failures:
                return {"total_failures": 0}
            
            # Group by error type
            by_type = {}
            for f in self._failures:
                if f.error_type not in by_type:
                    by_type[f.error_type] = []
                by_type[f.error_type].append(f)
            
            # Group by component
            by_component = {}
            for f in self._failures:
                if f.component not in by_component:
                    by_component[f.component] = []
                by_component[f.component].append(f)
            
            # Calculate recovery rate
            recovered_count = sum(1 for f in self._failures if f.recovered)
            recovery_rate = recovered_count / len(self._failures)
            
            return {
                "total_failures": len(self._failures),
                "by_type": {t: len(fs) for t, fs in by_type.items()},
                "by_component": {c: len(fs) for c, fs in by_component.items()},
                "recovery_rate": recovery_rate,
                "most_common_error": max(by_type.items(), key=lambda x: len(x[1]))[0]
            }
```

### 5. Documentation Architecture

**Living Documentation System:**
```python
from pathlib import Path
import json

class DocumentationGenerator:
    """
    Auto-generate documentation from execution data.
    
    Generates:
    1. overview-obsidian.canvas - Central systems map
    2. Architecture diagrams
    3. API reference
    4. Troubleshooting guides
    """
    
    @staticmethod
    async def generate_overview_canvas(
        output_path: Path,
        include_example: bool = True
    ):
        """
        Generate overview-obsidian.canvas with system architecture.
        
        Canvas Structure:
        - Core components (orchestrator, vLLM, agents)
        - Data flow (async patterns)
        - Observability layer
        - Links to detailed docs
        """
        nodes = []
        edges = []
        
        # Central orchestrator node
        nodes.append({
            "id": "orchestrator",
            "type": "text",
            "text": "## AsyncDyTopoOrchestrator\n\n"
                   "Core async multi-agent swarm\n\n"
                   "**Key Features:**\n"
                   "- vLLM inference backend\n"
                   "- Parallel descriptor generation\n"
                   "- Tiered agent execution\n"
                   "- Deterministic termination",
            "x": 0,
            "y": 0,
            "width": 300,
            "height": 250
        })
        
        # vLLM node
        nodes.append({
            "id": "vllm",
            "type": "text",
            "text": "## vLLM Server\n\n"
                   "High-throughput inference\n\n"
                   "- Async batch processing\n"
                   "- OpenAI-compatible API\n"
                   "- Continuous batching\n"
                   "- KV cache optimization",
            "x": -400,
            "y": -100,
            "width": 250,
            "height": 200
        })
        
        # Routing engine node
        nodes.append({
            "id": "routing",
            "type": "text",
            "text": "## AsyncRoutingEngine\n\n"
                   "Semantic message routing\n\n"
                   "- MiniLM embeddings\n"
                   "- Cosine similarity\n"
                   "- DAG construction\n"
                   "- Topological execution",
            "x": 400,
            "y": -100,
            "width": 250,
            "height": 200
        })
        
        # Delegation manager node
        nodes.append({
            "id": "delegation",
            "type": "text",
            "text": "## DelegationManager\n\n"
                   "Concurrent task delegation\n\n"
                   "- Depth limits\n"
                   "- Token budgets\n"
                   "- Mini-swarm creation\n"
                   "- Timeout handling",
            "x": -400,
            "y": 300,
            "width": 250,
            "height": 200
        })
        
        # Observability node
        nodes.append({
            "id": "observability",
            "type": "text",
            "text": "## Observability Layer\n\n"
                   "Distributed tracing & metrics\n\n"
                   "- Trace propagation\n"
                   "- Latency metrics\n"
                   "- Failure tracking\n"
                   "- Performance profiling",
            "x": 400,
            "y": 300,
            "width": 250,
            "height": 200
        })
        
        # Edges showing relationships
        edges.append({"from": "orchestrator", "to": "vllm", "label": "LLM calls"})
        edges.append({"from": "orchestrator", "to": "routing", "label": "builds graph"})
        edges.append({"from": "orchestrator", "to": "delegation", "label": "spawns tasks"})
        edges.append({"from": "observability", "to": "orchestrator", "label": "instruments"})
        
        # Build canvas JSON
        canvas = {
            "nodes": nodes,
            "edges": edges
        }
        
        output_path.write_text(json.dumps(canvas, indent=2))
        
        if include_example:
            # Generate example.png showing flow
            await DocumentationGenerator._generate_example_diagram(
                output_path.parent / "example.png"
            )
    
    @staticmethod
    async def _generate_example_diagram(output_path: Path):
        """Generate example system operation diagram."""
        # Use graphviz or matplotlib to create flow diagram
        # Showing: User query → Manager → Agents (parallel) → Routing → Execution → Result
        pass  # Implement with actual diagram library
    
    @staticmethod
    async def generate_api_reference(
        output_path: Path,
        orchestrator_class
    ):
        """Generate API reference from docstrings."""
        import inspect
        
        lines = [
            "# AsyncDyTopoOrchestrator API Reference",
            "",
            "## Overview",
            "",
            inspect.getdoc(orchestrator_class),
            "",
            "## Methods",
            ""
        ]
        
        for name, method in inspect.getmembers(orchestrator_class, inspect.isfunction):
            if name.startswith("_"):
                continue  # Skip private methods
            
            lines.append(f"### `{name}`")
            lines.append("")
            lines.append(inspect.getdoc(method) or "No documentation")
            lines.append("")
            
            # Signature
            sig = inspect.signature(method)
            lines.append(f"**Signature:** `{name}{sig}`")
            lines.append("")
        
        output_path.write_text("\n".join(lines))
```

## Implementation Tasks

### Phase 1: Distributed Tracing
- [ ] Implement `TraceContext` context manager
- [ ] Add `TraceCollector` for span storage
- [ ] Integrate tracing in all async operations
- [ ] Create trace export to JSON
- [ ] Build trace visualization tool
- [ ] Test trace propagation across async calls

### Phase 2: Metrics Collection
- [ ] Implement `MetricsCollector`
- [ ] Add latency metrics to all operations
- [ ] Track token consumption per agent
- [ ] Record error rates and types
- [ ] Create Prometheus export
- [ ] Build metrics dashboard (Grafana JSON)

### Phase 3: Performance Profiling
- [ ] Implement `PerformanceProfiler`
- [ ] Add CPU profiling integration
- [ ] Build `BottleneckAnalyzer`
- [ ] Create performance report generator
- [ ] Identify top 3 optimization opportunities
- [ ] Document optimization strategies

### Phase 4: Failure Analysis
- [ ] Implement `FailureAnalyzer`
- [ ] Add failure pattern detection
- [ ] Build recovery strategy suggestions
- [ ] Create failure report generator
- [ ] Test failure recovery flows
- [ ] Document common failure modes

### Phase 5: Documentation
- [ ] Generate overview-obsidian.canvas
- [ ] Create example.png system diagram
- [ ] Build auto-generated API reference
- [ ] Write troubleshooting guide
- [ ] Document all observability tools
- [ ] Create runbook for operations

## Delegation Strategy
You may delegate to sub-Claudes:
- **Tracing Implementation** - Build trace context and collector
- **Metrics System** - Implement metrics collection and aggregation
- **Profiling Tools** - Build performance profiling
- **Failure Analysis** - Implement failure tracking and analysis
- **Documentation Generator** - Build auto-doc system

## Success Criteria
✅ Every async operation has trace span
✅ Trace export shows complete execution tree
✅ Metrics capture latency per agent/round
✅ Performance profiler identifies bottlenecks
✅ Failure analyzer detects patterns
✅ overview-obsidian.canvas generated automatically
✅ API reference matches all public methods
✅ Troubleshooting guide covers common issues

## Testing Requirements
1. **Trace Tests**:
   - Trace propagation through nested async calls
   - Span hierarchy correctness
   - Trace export format validation

2. **Metrics Tests**:
   - Metric recording accuracy
   - Aggregation correctness (p95, p99)
   - Prometheus export format

3. **Profiling Tests**:
   - CPU profiling accuracy
   - Bottleneck detection
   - Recommendation generation

4. **Documentation Tests**:
   - Canvas generation from live system
   - API reference completeness
   - Diagram generation

## Files to Create/Modify
- `src/observability/tracing.py` - Distributed tracing
- `src/observability/metrics.py` - Metrics collection
- `src/observability/profiling.py` - Performance profiling
- `src/observability/failures.py` - Failure analysis
- `src/documentation/generator.py` - Doc generation
- `tests/test_tracing.py` - Trace tests
- `tests/test_metrics.py` - Metric tests
- `docs/overview-obsidian.canvas` - Generated canvas
- `docs/architecture/async-patterns.md` - Architecture doc
- `docs/operations/troubleshooting.md` - Troubleshooting guide

## Constraints
- NO silent instrumentation failures (always log)
- NO unbounded metric storage (implement retention)
- NO trace data in production logs (privacy)
- NO blocking operations in hot path
- NO undocumented observability features

## Integration Points
Your work depends on:
- `AsyncDyTopoOrchestrator` from Opus lead
- `AsyncRoutingEngine` from Sonnet Lead #1
- `DelegationManager` from Sonnet Lead #1

You provide:
- Tracing infrastructure for all components
- Metrics for performance analysis
- Profiling tools for optimization
- Documentation for maintainability

## Performance Budget
- Tracing overhead: <5% latency increase
- Metrics collection: <2% latency increase
- Total observability overhead: <10% latency increase

These are acceptable costs for production observability.

## Final Deliverable
Provide:
1. **Summary** of observability architecture
2. **Trace examples** from real swarm execution
3. **Metrics dashboard** (Grafana JSON or similar)
4. **Performance report** with bottleneck analysis
5. **Generated documentation** (canvas + API ref + guides)
6. **Runbook** for operational use

Remember: Observability is not optional in distributed systems. Make debugging a science, not an art.
